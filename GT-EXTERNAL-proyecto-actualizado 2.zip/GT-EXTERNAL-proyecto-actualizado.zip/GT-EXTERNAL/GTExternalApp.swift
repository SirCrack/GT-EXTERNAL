import SwiftUI

@main
struct GTExternalApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
