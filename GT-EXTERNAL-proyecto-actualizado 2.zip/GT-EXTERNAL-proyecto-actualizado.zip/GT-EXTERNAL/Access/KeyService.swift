import Foundation

struct KeyVerification: Decodable {
    let authorized: Bool
    let reason: String?
    let expires_at: String?
}

enum KeyService {
    static func verify(_ key: String, deviceID: String) async throws -> KeyVerification {
        let endpoint = AppConfig.supabaseURL
            .appendingPathComponent("functions")
            .appendingPathComponent("v1")
            .appendingPathComponent("verify-key")

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(AppConfig.supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(AppConfig.supabaseAnonKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "device_id": deviceID
        ])

        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(KeyVerification.self, from: data)
    }
}
