import Foundation

enum AppConfig {
    // Reemplaza estos valores por los de tu proyecto Supabase.
    static let supabaseURL = URL(string: "https://TU-PROYECTO.supabase.co")!
    static let supabaseAnonKey = "TU_CLAVE_PUBLICA_ANON"
}
