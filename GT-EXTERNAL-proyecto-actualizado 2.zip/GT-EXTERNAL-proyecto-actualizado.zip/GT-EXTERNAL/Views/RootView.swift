import SwiftUI

struct RootView: View {
    @State private var key = ""
    @State private var message = "Introduce tu clave de acceso"
    @State private var checking = false

    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.05, blue: 0.09).ignoresSafeArea()
            VStack(spacing: 22) {
                Text("GT EXTERNAL")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("Acceso privado")
                    .foregroundStyle(.white.opacity(0.7))
                SecureField("Clave de acceso", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding()
                    .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.white)
                Button {
                    message = "El servidor aún debe configurarse."
                } label: {
                    if checking { ProgressView().tint(.white) }
                    else { Text("Verificar clave").bold() }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue, in: RoundedRectangle(cornerRadius: 12))
                .foregroundStyle(.white)
                .disabled(key.isEmpty || checking)
                Text(message)
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.75))
            }
            .padding(28)
        }
    }
}
