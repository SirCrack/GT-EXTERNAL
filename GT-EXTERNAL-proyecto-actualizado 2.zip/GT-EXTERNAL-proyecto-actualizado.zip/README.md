# GT EXTERNAL — proyecto inicial

Este es un proyecto inicial de ejemplo para una app iOS independiente llamada GT EXTERNAL.

## Estado
- Incluye una interfaz SwiftUI básica para introducir una clave.
- Incluye un esquema SQL inicial y una Edge Function de ejemplo para validar claves.
- **No es una IPA** y todavía no está probado/compilado en Xcode.
- Antes de usarlo en producción hay que configurar Supabase, completar el panel de administración de claves, revisar la seguridad y compilar/firmar la app.

## Configuración
1. Crea un proyecto en Supabase.
2. Ejecuta `backend/schema.sql` en SQL Editor.
3. Despliega `backend/verify-key` como Edge Function y configura `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` como secretos del servidor.
4. Configura la URL y la clave pública anon de Supabase en `GT-EXTERNAL/Access/Config.swift`.
5. Abre el proyecto con Xcode en macOS para compilarlo.

Nunca incluyas `SUPABASE_SERVICE_ROLE_KEY` dentro de la app iOS ni la compartas por chat.
