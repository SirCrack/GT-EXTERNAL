create extension if not exists pgcrypto;

create table if not exists public.keys (
  id uuid primary key default gen_random_uuid(),
  key_value text unique not null,
  is_active boolean not null default true,
  expires_at timestamptz,
  max_devices integer not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists public.key_devices (
  id uuid primary key default gen_random_uuid(),
  key_id uuid not null references public.keys(id) on delete cascade,
  device_id text not null,
  first_seen_at timestamptz not null default now(),
  unique(key_id, device_id)
);

alter table public.keys enable row level security;
alter table public.key_devices enable row level security;

revoke all on public.keys from anon, authenticated;
revoke all on public.key_devices from anon, authenticated;

create or replace function public.verify_key(p_key text, p_device_id text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  k public.keys%rowtype;
  device_count integer;
begin
  select * into k from public.keys where key_value = p_key;
  if not found or not k.is_active then
    return jsonb_build_object('authorized', false, 'reason', 'invalid_or_inactive');
  end if;
  if k.expires_at is not null and k.expires_at <= now() then
    return jsonb_build_object('authorized', false, 'reason', 'expired');
  end if;

  insert into public.key_devices(key_id, device_id)
  values (k.id, p_device_id)
  on conflict (key_id, device_id) do nothing;

  select count(*) into device_count from public.key_devices where key_id = k.id;
  if device_count > k.max_devices then
    return jsonb_build_object('authorized', false, 'reason', 'device_limit');
  end if;

  return jsonb_build_object('authorized', true, 'reason', 'ok', 'expires_at', k.expires_at);
end;
$$;

revoke all on function public.verify_key(text, text) from public, anon, authenticated;
grant execute on function public.verify_key(text, text) to service_role;
