# Despliegue del backend

Este backend es un esqueleto inicial, no un servicio ya desplegado.

- Ejecuta `schema.sql` en el SQL Editor de Supabase.
- Despliega la función `verify-key`.
- Configura `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` como secretos del entorno de la función.
- No publiques la clave `service_role`.

Todavía falta construir un panel privado de administración para crear, consultar y desactivar claves. No compartas credenciales privadas en GitHub.
