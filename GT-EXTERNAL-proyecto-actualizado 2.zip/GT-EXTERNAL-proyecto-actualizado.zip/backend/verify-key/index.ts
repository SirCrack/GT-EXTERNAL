// Supabase Edge Function starter. Deploy with Supabase CLI or dashboard.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { key, device_id } = await req.json();
    if (typeof key !== "string" || typeof device_id !== "string" || !key || !device_id) {
      return Response.json({ authorized: false, reason: "missing_fields" }, { status: 400, headers: cors });
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const { data, error } = await supabase.rpc("verify_key", {
      p_key: key,
      p_device_id: device_id
    });
    if (error) throw error;
    return Response.json(data, { headers: cors });
  } catch (_error) {
    return Response.json({ authorized: false, reason: "server_error" }, { status: 500, headers: cors });
  }
});
