# GitHub Actions

El workflow `.github/workflows/ios-build.yml` compila una versión para el simulador iOS como primera prueba.
Eso NO genera una IPA instalable en un iPhone.

Para generar una IPA real hay que configurar firma de distribución de Apple (certificado y provisioning profile) en GitHub Secrets y ajustar el workflow para archivar/exportar. Nunca subas certificados privados, contraseñas ni claves de servicio al repositorio.
