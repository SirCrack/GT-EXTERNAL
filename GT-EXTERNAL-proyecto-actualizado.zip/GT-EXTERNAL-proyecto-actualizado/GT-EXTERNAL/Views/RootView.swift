import SwiftUI

struct RootView: View {
    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.05, blue: 0.09)
                .ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                Image(systemName: "bolt.shield.fill")
                    .font(.system(size: 65))
                    .foregroundStyle(.blue)

                Text("GT EXTERNAL")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)

                Text("Bienvenido")
                    .font(.title3)
                    .foregroundStyle(.white.opacity(0.7))

                Text("Tu aplicación está lista.")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.6))

                Spacer()

                Text("GT EXTERNAL • iOS")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.4))
                    .padding(.bottom, 20)
            }
            .padding(28)
        }
    }
}
