
import SwiftUI

struct RootView: View {
    @State private var selectedTab = 0

    private let background = Color(red: 0.035, green: 0.045, blue: 0.08)
    private let accent = Color(red: 0.20, green: 0.48, blue: 1.0)

    var body: some View {
        ZStack {
            background.ignoresSafeArea()

            VStack(spacing: 0) {
                header

                ScrollView(showsIndicators: false) {
                    if selectedTab == 0 {
                        home
                    } else if selectedTab == 1 {
                        tools
                    } else {
                        settings
                    }
                }

                tabBar
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("GT EXTERNAL")
                    .font(.system(size: 23, weight: .black))
                    .foregroundStyle(.white)

                Text("CONTROL CENTER")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(3)
                    .foregroundStyle(accent)
            }

            Spacer()

            Image(systemName: "bolt.shield.fill")
                .font(.system(size: 25))
                .foregroundStyle(accent)
                .padding(12)
                .background(accent.opacity(0.15), in: RoundedRectangle(cornerRadius: 15))
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 18)
    }

    private var home: some View {
        VStack(alignment: .leading, spacing: 22) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 24)
                    .fill(
                        LinearGradient(
                            colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.65), Color.black],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )

                VStack(alignment: .leading, spacing: 10) {
                    Text("BIENVENIDO")
                        .font(.caption.bold())
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.75))

                    Text("Tu centro de\ncontrol.")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundStyle(.white)

                    Text("GT EXTERNAL • iOS")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                }
                .padding(24)
            }
            .frame(height: 190)

            Text("PANEL PRINCIPAL")
                .font(.caption.bold())
                .tracking(2)
                .foregroundStyle(.white.opacity(0.55))

            HStack(spacing: 12) {
                statusCard("Aplicación", "Activa", "checkmark.circle.fill")
                statusCard("Versión", "1.0", "app.badge")
            }

            Text("ACCESOS")
                .font(.caption.bold())
                .tracking(2)
                .foregroundStyle(.white.opacity(0.55))

            Button {
                selectedTab = 1
            } label: {
                menuCard("Herramientas", "Explora los módulos disponibles", "square.grid.2x2.fill")
            }

            Button {
                selectedTab = 2
            } label: {
                menuCard("Configuración", "Información de la aplicación", "gearshape.fill")
            }
        }
        .padding(20)
    }

    private var tools: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("HERRAMIENTAS")
                .font(.title2.bold())
                .foregroundStyle(.white)

            Text("Aquí podrás organizar los módulos de GT EXTERNAL.")
                .foregroundStyle(.white.opacity(0.6))

            menuCard("Módulo principal", "Espacio para futuras funciones", "cpu.fill")
            menuCard("Parches", "Sección reservada para futuras versiones", "wrench.and.screwdriver.fill")
            menuCard("Compatibilidad", "Información de versiones y dispositivos", "iphone.gen3")
        }
        .padding(20)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("CONFIGURACIÓN")
                .font(.title2.bold())
                .foregroundStyle(.white)

            menuCard("Nombre", "GT EXTERNAL", "app.fill")
            menuCard("Plataforma", "Apple iOS", "iphone")
            menuCard("Versión", "1.0", "number")
            menuCard("Estado", "Interfaz inicial instalada", "checkmark.circle.fill")
        }
        .padding(20)
    }

    private func statusCard(_ title: String, _ value: String, _ symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: symbol)
                .font(.title2)
                .foregroundStyle(accent)

            Text(title)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.55))

            Text(value)
                .font(.headline.bold())
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(17)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
    }

    private func menuCard(_ title: String, _ subtitle: String, _ symbol: String) -> some View {
        HStack(spacing: 15) {
            Image(systemName: symbol)
                .font(.title2)
                .foregroundStyle(accent)
                .frame(width: 48, height: 48)
                .background(accent.opacity(0.15), in: RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundStyle(.white.opacity(0.4))
        }
        .padding(15)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
    }

    private var tabBar: some View {
        HStack {
            tabButton("Inicio", "house.fill", 0)
            tabButton("Herramientas", "square.grid.2x2.fill", 1)
            tabButton("Ajustes", "gearshape.fill", 2)
        }
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(Color.black.opacity(0.35))
    }

    private func tabButton(_ title: String, _ symbol: String, _ index: Int) -> some View {
        Button {
            selectedTab = index
        } label: {
            VStack(spacing: 6) {
                Image(systemName: symbol)
                    .font(.system(size: 19))

                Text(title)
                    .font(.system(size: 10, weight: .semibold))
            }
            .foregroundStyle(selectedTab == index ? accent : .white.opacity(0.5))
            .frame(maxWidth: .infinity)
        }
    }
}
