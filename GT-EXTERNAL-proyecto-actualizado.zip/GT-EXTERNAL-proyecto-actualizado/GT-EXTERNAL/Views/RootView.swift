
import SwiftUI
import UniformTypeIdentifiers

struct PatchItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var fileName: String
    var enabled = false
}

struct RootView: View {
    @State private var selectedTab = 0
    @State private var patches: [PatchItem] = []
    @State private var showImporter = false
    @State private var selectedPatch: PatchItem?
    @State private var message = ""

    private let blue = Color(red: 0.15, green: 0.48, blue: 1)

    var body: some View {
        TabView(selection: $selectedTab) {
            home
                .tabItem {
                    Label("Inicio", systemImage: "house.fill")
                }
                .tag(0)

            patchScreen
                .tabItem {
                    Label("Parches", systemImage: "square.stack.3d.up.fill")
                }
                .tag(1)

            settings
                .tabItem {
                    Label("Ajustes", systemImage: "gearshape.fill")
                }
                .tag(2)
        }
        .tint(blue)
        .preferredColorScheme(.dark)
        .onAppear(perform: loadPatches)
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.data],
            allowsMultipleSelection: true
        ) { result in
            importFiles(result)
        }
        .sheet(item: $selectedPatch) { patch in
            patchDetails(patch)
                .presentationDetents([.medium])
        }
    }

    private var background: some View {
        Color(red: 0.035, green: 0.045, blue: 0.075)
            .ignoresSafeArea()
    }

    private var home: some View {
        ZStack {
            background

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    header

                    VStack(alignment: .leading, spacing: 12) {
                        Text("CONTROL CENTER")
                            .font(.caption.bold())
                            .foregroundStyle(blue)

                        Text("Bienvenido a GT EXTERNAL")
                            .font(.title2.bold())
                            .foregroundStyle(.white)

                        Text("Administra tus herramientas y archivos de parches.")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(panel)
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                    HStack(spacing: 12) {
                        statusCard("Parches", value: "\(patches.count)", icon: "square.stack.3d.up")
                        statusCard("Activos", value: "\(patches.filter { $0.enabled }.count)", icon: "checkmark.circle")
                    }

                    Button {
                        selectedTab = 1
                    } label: {
                        Label("Abrir gestor de parches", systemImage: "arrow.right.circle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(blue, in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.white)
                    }
                }
                .padding(20)
            }
        }
    }

    private var header: some View {
        HStack {
            Image(systemName: "bolt.shield.fill")
                .font(.system(size: 28))
                .foregroundStyle(blue)

            VStack(alignment: .leading, spacing: 2) {
                Text("GT EXTERNAL")
                    .font(.title2.bold())
                    .foregroundStyle(.white)

                Text("PATCH MANAGER")
                    .font(.caption2.bold())
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.45))
            }

            Spacer()

            Circle()
                .fill(.green)
                .frame(width: 9, height: 9)
        }
    }

    private var patchScreen: some View {
        ZStack {
            background

            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("GESTOR DE PARCHES")
                            .font(.caption.bold())
                            .tracking(1.5)
                            .foregroundStyle(blue)

                        Text("Mis parches")
                            .font(.largeTitle.bold())
                            .foregroundStyle(.white)
                    }

                    Spacer()

                    Button {
                        showImporter = true
                    } label: {
                        Image(systemName: "plus")
                            .font(.title2.bold())
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(blue, in: RoundedRectangle(cornerRadius: 14))
                    }
                }

                Button {
                    showImporter = true
                } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "square.and.arrow.down.fill")
                            .font(.title2)
                            .foregroundStyle(blue)

                        VStack(alignment: .leading, spacing: 4) {
                            Text("Importar parche")
                                .font(.headline)
                                .foregroundStyle(.white)

                            Text("Selecciona un archivo .3105")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.55))
                        }

                        Spacer()

                        Image(systemName: "chevron.right")
                            .foregroundStyle(.white.opacity(0.4))
                    }
                    .padding(16)
                    .background(panel)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }

                HStack {
                    Text("ARCHIVOS IMPORTADOS")
                        .font(.caption.bold())
                        .tracking(1)
                        .foregroundStyle(.white.opacity(0.5))

                    Spacer()

                    Text("\(patches.count)")
                        .font(.caption.bold())
                        .foregroundStyle(blue)
                }

                if patches.isEmpty {
                    Spacer()

                    Image(systemName: "square.stack.3d.up")
                        .font(.system(size: 48))
                        .foregroundStyle(.white.opacity(0.2))

                    Text("No hay parches importados")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.7))

                    Text("Importa un archivo .3105 para verlo aquí.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.4))

                    Spacer()
                } else {
                    List {
                        ForEach(patches) { patch in
                            HStack(spacing: 12) {
                                Image(systemName: "doc.zipper")
                                    .font(.title2)
                                    .foregroundStyle(blue)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(patch.name)
                                        .font(.subheadline.bold())
                                        .foregroundStyle(.white)

                                    Text(patch.enabled ? "Activado en el gestor" : "Desactivado")
                                        .font(.caption)
                                        .foregroundStyle(.white.opacity(0.5))
                                }

                                Spacer()

                                Toggle("", isOn: Binding(
                                    get: { patches.first(where: { $0.id == patch.id })?.enabled ?? false },
                                    set: { newValue in
                                        updatePatch(patch, enabled: newValue)
                                    }
                                ))
                                .labelsHidden()
                                .tint(blue)
                            }
                            .listRowBackground(panel)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedPatch = patch
                            }
                            .swipeActions {
                                Button(role: .destructive) {
                                    deletePatch(patch)
                                } label: {
                                    Label("Eliminar", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.plain)
                }

                if !message.isEmpty {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            .padding(20)
        }
    }

    private var settings: some View {
        ZStack {
            background

            VStack(spacing: 18) {
                header

                settingsRow("Versión", value: "1.0", icon: "info.circle")
                settingsRow("Sistema", value: "iOS", icon: "iphone")
                settingsRow("Parches importados", value: "\(patches.count)", icon: "doc")

                Spacer()

                Text("GT EXTERNAL • PATCH MANAGER")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.3))
            }
            .padding(20)
        }
    }

    private var panel: Color {
        Color(red: 0.075, green: 0.09, blue: 0.14)
    }

    private func statusCard(_ title: String, value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(blue)

            Text(value)
                .font(.title.bold())
                .foregroundStyle(.white)

            Text(title)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(panel)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func settingsRow(_ title: String, value: String, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
                .foregroundStyle(blue)
            Text(title)
                .foregroundStyle(.white)
            Spacer()
            Text(value)
                .foregroundStyle(.white.opacity(0.5))
        }
        .padding(16)
        .background(panel)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func patchDetails(_ patch: PatchItem) -> some View {
        ZStack {
            background

            VStack(alignment: .leading, spacing: 16) {
                Text("DETALLES DEL PARCHE")
                    .font(.caption.bold())
                    .foregroundStyle(blue)

                Text(patch.name)
                    .font(.title2.bold())
                    .foregroundStyle(.white)

                Text("Archivo: \(patch.fileName)")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.6))

                Text("Estado: \(patch.enabled ? "Activado en el gestor" : "Desactivado")")
                    .foregroundStyle(.white.opacity(0.7))

                Text("La activación solo cambia el estado dentro de GT EXTERNAL; no modifica otras aplicaciones.")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.5))

                Spacer()
            }
            .padding(24)
        }
    }

    private func documentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func loadPatches() {
        let url = documentsDirectory().appendingPathComponent("patches.json")
        if let data = try? Data(contentsOf: url),
           let saved = try? JSONDecoder().decode([PatchItem].self, from: data) {
            patches = saved
        }
    }

    private func savePatches() {
        let url = documentsDirectory().appendingPathComponent("patches.json")
        if let data = try? JSONEncoder().encode(patches) {
            try? data.write(to: url, options: .atomic)
        }
    }

    private func importFiles(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            for url in urls {
                guard url.pathExtension.lowercased() == "3105" else {
                    message = "Solo se admiten archivos .3105."
                    continue
                }

                let access = url.startAccessingSecurityScopedResource()
                defer {
                    if access {
                        url.stopAccessingSecurityScopedResource()
                    }
                }

                let destination = documentsDirectory().appendingPathComponent(url.lastPathComponent)

                do {
                    if FileManager.default.fileExists(atPath: destination.path) {
                        try FileManager.default.removeItem(at: destination)
                    }

                    try FileManager.default.copyItem(at: url, to: destination)

                    let name = url.deletingPathExtension().lastPathComponent
                    patches.append(PatchItem(name: name, fileName: url.lastPathComponent))
                    message = "Parche importado correctamente."
                } catch {
                    message = "No se pudo importar el archivo."
                }
            }

            savePatches()

        case .failure:
            message = "No se pudo abrir el selector de archivos."
        }
    }

    private func updatePatch(_ patch: PatchItem, enabled: Bool) {
        guard let index = patches.firstIndex(where: { $0.id == patch.id }) else { return }
        patches[index].enabled = enabled
        savePatches()
    }

    private func deletePatch(_ patch: PatchItem) {
        let file = documentsDirectory().appendingPathComponent(patch.fileName)
        try? FileManager.default.removeItem(at: file)
        patches.removeAll { $0.id == patch.id }
        savePatches()
    }
}
